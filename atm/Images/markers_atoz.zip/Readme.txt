
3D Google markers: A to Z, 0 to 9, some punctuation

Here are 48 transparent png files suitable for use as Google Map markers.
They all use the default shadow, so you can use them with a base icon like this:

      // Create a base icon for all of our markers
      var baseIcon = new GIcon();
       baseIcon.shadow = "http://www.google.com/mapfiles/shadow50.png";
       baseIcon.iconSize = new GSize(20, 34);
       baseIcon.shadowSize = new GSize(37, 34);
       baseIcon.iconAnchor = new GPoint(9, 34);
       baseIcon.infoWindowAnchor = new GPoint(9, 2);
       baseIcon.infoShadowAnchor = new GPoint(18, 25);

      // Create an actual marker
      var icon = new GIcon(baseIcon);
      icon.image = "markerA.png";
      var markerA = new GMarker(point, icon);

      // Create marker in range A to Z indexed by i
      var icon = new GIcon(baseIcon);
      var letter = String.fromCharCode("A".charCodeAt(0) + i);
      icon.image = "marker" + letter + ".png";
      var marker = new GMarker(point, icon);

Also included is teh POVRay source code that I used to generate them,
for people who want to produce their own modified versions.
POVRay is a free raytracing program <www.povray.org>.

-- 
Mike Williams
